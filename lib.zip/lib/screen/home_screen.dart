import 'package:flutter/material.dart';

// Tela principal da loja
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Lista de produtos (mock) com nome, preço e imagem
  final List<Map<String, dynamic>> produtos = [
    {
      "nome": "iPhone 15",
      "preco": 7999.00,
      "imagem": "https://via.placeholder.com/120",
    },
    {
      "nome": "Samsung Galaxy S24",
      "preco": 6999.00,
      "imagem": "https://via.placeholder.com/120",
    },
    {
      "nome": "Xiaomi 13 Pro",
      "preco": 4999.00,
      "imagem": "https://via.placeholder.com/120",
    },
    {
      "nome": "Motorola Galaxy G82",
      "preco": 3999.00,
      "imagem": "https://via.placeholder.com/120",
    },
  ];

  @override
  Widget build(BuildContext context) {
    // Pega a largura da tela do dispositivo para ajustar layout dinamicamente
    final larguraTela = MediaQuery.of(context).size.width;

    return Scaffold(
      // Barra superior da aplicação
      appBar: AppBar(
        title: const Text("MyShop"),
        backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      ),
      body: Container(
        // Fundo com gradiente roxo
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.deepPurple, Colors.deepPurple.shade200],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        // Grid para exibir os produtos
        child: GridView.builder(
          padding: const EdgeInsets.all(10),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            // Se a tela for larga (ex: tablet), mostra 3 colunas, senão 2
            crossAxisCount: larguraTela > 600 ? 3 : 2,
            crossAxisSpacing: 10, // espaçamento horizontal entre cards
            mainAxisSpacing: 10, // espaçamento vertical entre cards
            childAspectRatio: 0.7, // proporção largura/altura dos cards
          ),
          itemCount: produtos.length, // quantidade de produtos
          itemBuilder: (context, index) {
            final produto = produtos[index]; // produto atual
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12), // bordas arredondadas
              ),
              elevation: 6, // sombra do card
              child: Padding(
                padding: const EdgeInsets.all(8.0), // espaçamento interno
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Imagem proporcional ao espaço disponível
                    // Imagem responsiva
                    // Imagem quadrada e responsiva
                    AspectRatio(
                      aspectRatio: 1, // 1:1 garante que seja quadrada
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(
                          8,
                        ), // bordas arredondadas
                        child: Image.network(
                          produto["imagem"],
                          fit: BoxFit
                              .cover, // cobre todo o espaço mantendo proporção
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Nome do produto
                    Text(
                      produto["nome"],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 4),
                    // Preço do produto
                    Text(
                      "R\$ ${produto["preco"].toStringAsFixed(2)}",
                      style: const TextStyle(
                        color: Colors.deepPurple,
                        fontSize: 14,
                      ),
                    ),
                    const Spacer(), // empurra o botão para baixo
                    // Botão Comprar adaptável
                    SizedBox(
                      width: double.infinity, // ocupa toda a largura do card
                      height: 25, // altura fixa
                      child: ElevatedButton(
                        onPressed: () {
                          // Exibe mensagem ao adicionar ao carrinho
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                "${produto["nome"]} adicionado ao carrinho!",
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple, // cor do botão
                          foregroundColor: Colors.white, // cor do texto
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              8,
                            ), // bordas arredondadas
                          ),
                        ),
                        child: const Text(
                          "Comprar",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
